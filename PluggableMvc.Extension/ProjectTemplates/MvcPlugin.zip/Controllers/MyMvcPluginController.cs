﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;

namespace $safeprojectname$.Controllers
{
	public class $projectname$Controller : Controller
	{
		public ActionResult Index()
		{
			string message = "Message from $projectname$Controller!";

			ViewData["message"] = message;
			return View();
		}
	}
}
