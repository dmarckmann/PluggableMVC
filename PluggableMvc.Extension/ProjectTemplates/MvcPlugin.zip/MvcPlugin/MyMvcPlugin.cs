﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PluggableMvc;
using System.ComponentModel.Composition;

namespace $safeprojectname$.MvcPlugin
{
	[Export(typeof(IMvcPlugin))]
	public class $projectname$ : IMvcPlugin
	{
		public string DisplayName
		{
			get { return "$projectname$"; }
		}
		public string DefaultControllerName
		{
			get { return "$projectname$"; }
		}
		public string DefaultActionName
		{
			get { return "Index"; }
		}
	}
}
